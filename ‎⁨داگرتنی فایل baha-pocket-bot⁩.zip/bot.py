
from telegram import Update
from telegram.ext import Updater, CommandHandler, CallbackContext
import logging

# Bot token
TOKEN = "7590212589:AAEih6ZlXkcofrWUDpQMpSv-rb6NZEMqGDg"

# VIP User IDs
VIP_USERS = [123456789]  # <-- بگۆڕە بە IDی خۆت

# Chart Image URL (تاقیە بکە بەو وێنەی کە تۆ دەتەوێت)
chart_url = "https://i.ibb.co/fFTJLzT/sample-chart.png"

# Logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

def start(update: Update, context: CallbackContext):
    if update.effective_user.id in VIP_USERS:
        update.message.reply_text("🎉 بەخێربێیت بۆ VIP بۆتی سیگناڵ!")
    else:
        update.message.reply_text("🚫 تۆ VIP نیت. پەیوەندیم پێوە بکە بۆ بەشداربوون.")

def signal(update: Update, context: CallbackContext):
    if update.effective_user.id in VIP_USERS:
        text = (
            "📈 سیگناڵی ئەمڕۆ:
"
            "Asset: EUR/USD
"
            "Type: BUY
"
            "Timeframe: 1m
"
            "Confidence: 🔥🔥🔥
"
            "⏰ Time: 14:30"
        )
        update.message.reply_photo(photo=chart_url, caption=text)
    else:
        update.message.reply_text("🚫 تۆ بەشدار نییە لە VIP.")

def main():
    updater = Updater(TOKEN)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("signal", signal))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
